public class Main {

	public static void main(String[] args) {
		
		//You may test that your code works find here
		//Please check that your code works and has no 
		//compilation problems before to submit
		
		Student[] std=new Student[5];
		{
			for(int i=0;i<7;i++)
			{
				Scanner s1=new Scanner(System.in);
				System.out.println("What is your ID number: ");
				std[i].setId(s1.nextLine());
				System.out.println("What is your name: ");
				std[i].setFullName(s1.nextLine());
				System.out.println("What is your Date of birth: ");
				std[i].setBirthDate(s1.nextLine());
				System.out.println("What is your average marks: ");
				std[i].setAvgMark(s1.nextLine());
			}
		}
	}

}
